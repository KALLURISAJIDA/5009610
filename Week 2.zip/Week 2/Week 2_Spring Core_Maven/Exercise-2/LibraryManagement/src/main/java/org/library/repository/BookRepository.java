package org.library.repository;

import java.util.*;
public class BookRepository {
    public List<String> getBooks()
    {
        return Arrays.asList("book1","book2","book3");
    }

}
