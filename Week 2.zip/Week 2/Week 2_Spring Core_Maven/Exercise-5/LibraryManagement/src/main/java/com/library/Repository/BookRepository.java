package com.library.Repository;


import  java.util.*;

public class BookRepository {

    public List<String> getBooks()
    {
        return Arrays.asList("Book1","Book2","Book3");
    }
}
